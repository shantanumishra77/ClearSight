export type VisionConditionId =
  | 'normal'
  | 'cataracts'
  | 'deuteranopia'
  | 'protanopia'
  | 'tritanopia'
  | 'achromatopsia'
  | 'glaucoma'
  | 'amd'
  | 'diabetic-retinopathy'
  | 'retinitis-pigmentosa';

export type VarietyCategory = 'All' | 'Lens & Cornea' | 'Color Vision' | 'Retina & Nerve';

export interface VisionCondition {
  id: VisionConditionId;
  name: string;
  shortName: string;
  category: Exclude<VarietyCategory, 'All'>;
  prevalence: string;
  affectedPart: string;
  summary: string;
  howPeopleSee: string;
  visualSigns: string[];
  medicalTreatments: string[];
  selfCareSteps: string[];
  assistiveTools: string[];
}

export interface SceneAsset {
  id: string;
  title: string;
  subtitle: string;
  imageUrl: string;
  alt: string;
  whyUseful: string;
}

export interface EyePartInfo {
  id: 'cornea' | 'iris' | 'lens' | 'retina' | 'optic-nerve';
  name: string;
  role: string;
  whenAffected: string;
  linkedConditions: string[];
}

export const HERO_BANNER_IMAGE = '/src/assets/images/hero_vision_banner_1795328690393.jpg';
export const EYE_CARE_IMAGE = '/src/assets/images/eye_care_prevention_1795328691362.jpg';

export const SCENE_ASSETS: SceneAsset[] = [
  {
    id: 'market',
    title: 'Colorful Outdoor Market',
    subtitle: 'Strawberries, green apples, lemons, figs & blue ceramics',
    imageUrl: '/src/assets/images/scene_botanical_market_1795328690700.jpg',
    alt: 'Vibrant outdoor farmers market stall with bright red strawberries, green apples, yellow lemons, purple figs, orange marigolds, and blue ceramic bowls',
    whyUseful: 'Reveals how red-green and blue-yellow color blindness shift produce colors and how contrast loss softens edges.',
  },
  {
    id: 'crosswalk',
    title: 'Sunlit City Crosswalk',
    subtitle: 'Traffic signals, street signs, yellow cab & pedestrians',
    imageUrl: '/src/assets/images/scene_city_crosswalk_1795328690749.jpg',
    alt: 'Daytime city street crosswalk with red and green pedestrian traffic lights, yellow taxi, blue street sign, green trees, and pedestrians',
    whyUseful: 'Shows why peripheral tunnel vision (glaucoma) hides approaching traffic and why traffic signal colors blend in color vision deficiency.',
  },
  {
    id: 'reading',
    title: 'Sunlit Reading Table',
    subtitle: 'Open printed book, eyeglasses, ceramic teacup & window light',
    imageUrl: '/src/assets/images/scene_reading_livingroom_1795328689854.jpg',
    alt: 'Warm living room wooden table with an open book showing printed text, eyeglasses, a ceramic teacup, and potted green plants by a sunny window',
    whyUseful: 'Demonstrates how central scotomas (macular degeneration) block printed words and how bright window glare washes out text with cataracts.',
  },
];

export const EYE_ANATOMY_PARTS: EyePartInfo[] = [
  {
    id: 'cornea',
    name: 'Cornea',
    role: 'The clear, curved front window of the eye that bends incoming light toward the pupil.',
    whenAffected: 'Scarring, infection, or swelling clouds the cornea and scatters light, causing hazy or distorted vision.',
    linkedConditions: ['Corneal Opacity', 'Keratoconus', 'Trachoma'],
  },
  {
    id: 'iris',
    name: 'Iris & Pupil',
    role: 'The colored muscular ring that opens and narrows the pupil to control how much light enters.',
    whenAffected: 'Irregular light regulation can cause severe glare sensitivity or poor low-light adaptation.',
    linkedConditions: ['Photophobia', 'Aniridia', 'Uveitis'],
  },
  {
    id: 'lens',
    name: 'Natural Lens',
    role: 'A flexible transparent disc behind the pupil that fine-tunes focus for near and far objects.',
    whenAffected: 'With age, UV exposure, or diabetes, lens proteins clump together, turning the clear lens milky or amber-brown.',
    linkedConditions: ['Cataracts', 'Presbyopia'],
  },
  {
    id: 'retina',
    name: 'Retina & Macula',
    role: 'Light-sensitive neural tissue lining the back of the eye. Cones detect color and sharp detail at the central macula; rods handle side and night vision.',
    whenAffected: 'Damage to cones causes color blindness or central blind spots; rod or blood-vessel damage causes night blindness, floaters, or patchy dark areas.',
    linkedConditions: ['Macular Degeneration', 'Color Blindness', 'Diabetic Retinopathy', 'Retinitis Pigmentosa'],
  },
  {
    id: 'optic-nerve',
    name: 'Optic Nerve',
    role: 'A bundle of over one million nerve fibers carrying visual signals from the retina to the brain.',
    whenAffected: 'Elevated eye fluid pressure or reduced blood flow slowly damages peripheral nerve fibers first, narrowing the field of view.',
    linkedConditions: ['Glaucoma', 'Optic Nerve Atrophy'],
  },
];

export const VISION_CONDITIONS: VisionCondition[] = [
  {
    id: 'cataracts',
    name: 'Cataracts',
    shortName: 'Cataracts',
    category: 'Lens & Cornea',
    prevalence: '~94 million people worldwide',
    affectedPart: 'Natural Lens',
    summary:
      'A clouding of the eye’s naturally clear lens. As proteins clump over time, light scatters instead of focusing cleanly onto the retina.',
    howPeopleSee:
      'Colors look faded or yellowed, bright headlights or sunlit windows create blinding glare and halos, and fine details appear as if viewed through a foggy or frosted window.',
    visualSigns: [
      'Cloudy, milky, or hazy overall blur',
      'Faded blues and yellowed whites',
      'Bright halos and strong glare around lights',
    ],
    medicalTreatments: [
      'Outpatient cataract surgery replacing the clouded lens with a clear artificial intraocular lens (IOL)',
      'Updated prescription eyeglasses during early stages before surgery is needed',
      'Anti-glare lens coatings prescribed by an optometrist',
    ],
    selfCareSteps: [
      'Use warm, directional task lamps pointed onto reading pages rather than overhead glare',
      'Wear polarized wrap-around sunglasses and a brimmed hat outdoors',
      'Increase text size and contrast on phones, tablets, and kitchen timers',
    ],
    assistiveTools: [
      'Amber or yellow-tinted anti-glare clip-on glasses',
      'Illuminated hand-held magnifiers',
      'High-contrast large-print books and bold-felt pens',
    ],
  },
  {
    id: 'deuteranopia',
    name: 'Red-Green Color Blindness (Deuteranopia)',
    shortName: 'Deuteranopia',
    category: 'Color Vision',
    prevalence: '~1 in 12 men · ~1 in 200 women',
    affectedPart: 'Retinal Green-Sensitive Cones',
    summary:
      'The most common form of color vision deficiency, where green-sensing cone photoreceptors are absent or altered, making reds, greens, and browns overlap.',
    howPeopleSee:
      'Ripe red strawberries and bright green apples lose their sharp color contrast and shift toward muted golden-olive and earthy tan hues, while blue and yellow remain distinct.',
    visualSigns: [
      'Red and green look nearly identical (muted olive/brown)',
      'Purple blends closely with blue',
      'Brightness and texture remain sharp and clear',
    ],
    medicalTreatments: [
      'Inherited color vision deficiency currently has no medical cure, though gene-therapy trials are ongoing',
      'Consult an optometrist for an Ishihara or anomaloscope test to identify the exact type and severity',
      'If color vision changes suddenly later in life, seek urgent evaluation to rule out optic nerve or retinal disease',
    ],
    selfCareSteps: [
      'Organize clothing and cables using textured tags or written color labels',
      'Learn traffic signal positions (top is red, bottom is green) rather than relying only on hue',
      'Use meat thermometers when cooking instead of judging redness or browning by eye',
    ],
    assistiveTools: [
      'Built-in OS color filters (iOS/Android/Windows Deuteranopia modes)',
      'Color-naming smartphone camera apps for matching outfits or produce',
      'Specially notched optical filter glasses for outdoor color separation',
    ],
  },
  {
    id: 'protanopia',
    name: 'Red-Weak Color Blindness (Protanopia)',
    shortName: 'Protanopia',
    category: 'Color Vision',
    prevalence: '~1% of males',
    affectedPart: 'Retinal Red-Sensitive Cones',
    summary:
      'Occurs when red-sensing L-cone cells do not function, causing red wavelengths to appear noticeably darker as well as shifting toward brownish-yellow.',
    howPeopleSee:
      'Deep reds—like brake lights, stop signs, or dark berries—appear dim, charcoal, or dark olive, while greens and yellows merge into warm beige and gold tones.',
    visualSigns: [
      'Reds appear noticeably darker and duller than normal',
      'Red, orange, and green merge into muted yellow-browns',
      'Pink and light blue can look almost identical',
    ],
    medicalTreatments: [
      'Comprehensive color vision diagnostic testing with an eye care specialist',
      'Screenings for family members if inherited, or retinal exams if acquired later in adulthood',
    ],
    selfCareSteps: [
      'Avoid relying solely on red LED indicator lights—look for text labels or switch positions',
      'Keep extra distance while driving at dusk so dim red brake lights are recognized early by shape and position',
      'Ask teachers or colleagues to use symbols and patterns alongside color-coded charts',
    ],
    assistiveTools: [
      'Protanopia accessibility color correction in smartphone settings',
      'High-contrast browser extensions that add patterns to graphs',
      'Tactile and labeled spice, battery, and charger organizers',
    ],
  },
  {
    id: 'tritanopia',
    name: 'Blue-Yellow Color Blindness (Tritanopia)',
    shortName: 'Tritanopia',
    category: 'Color Vision',
    prevalence: '~1 in 10,000 people',
    affectedPart: 'Retinal Blue-Sensitive Cones',
    summary:
      'A rarer deficiency affecting short-wavelength S-cone receptors. Unlike red-green types, it affects men and women equally and can also be acquired from eye disease.',
    howPeopleSee:
      'Bright blue skies and ceramic bowls shift toward teal-green, while yellow lemons and orange flowers look pale pink, lavender, or light grey.',
    visualSigns: [
      'Blues look greenish-teal; dark blues look almost black',
      'Yellows fade into pale pink or neutral white',
      'Purple and deep red become difficult to separate',
    ],
    medicalTreatments: [
      'Prompt eye exam if acquired suddenly, as tritan defects can signal glaucoma, cataracts, or retinal stress',
      'Regular monitoring of overall retinal health with an optometrist',
    ],
    selfCareSteps: [
      'Use high-contrast black-on-white labels rather than yellow-on-white sticky notes',
      'Check expiration dates and ripeness by texture, scent, and printed dates rather than yellow/green tones',
    ],
    assistiveTools: [
      'Tritanopia display filters in mobile and desktop accessibility menus',
      'Real-time camera color-identification apps',
    ],
  },
  {
    id: 'achromatopsia',
    name: 'Complete Color Blindness (Achromatopsia)',
    shortName: 'Achromatopsia',
    category: 'Color Vision',
    prevalence: '~1 in 30,000 people',
    affectedPart: 'All Cone Photoreceptors',
    summary:
      'A rare condition where cone photoreceptors do not respond to light, leaving vision driven primarily by rod cells—resulting in grayscale sight, reduced sharpness, and strong daylight sensitivity.',
    howPeopleSee:
      'The entire world appears in shades of black, white, and silver-grey, often accompanied by bright daylight washout and softer focus.',
    visualSigns: [
      'Complete absence of hue (monochrome grayscale)',
      'Intense discomfort and glare in bright sunlight',
      'Reduced sharpness for small distant details',
    ],
    medicalTreatments: [
      'Low-vision specialist fitting for deeply tinted red or amber therapeutic lenses',
      'Genetic counseling and ongoing retinal monitoring',
    ],
    selfCareSteps: [
      'Wear dark wrap-around red-tinted or Category 4 sunglasses outdoors to prevent photophobia washout',
      'Use matte screens, blackout blinds, and adjustable dimmers indoors',
      'Organize objects strictly by shape, size, and tactile labels',
    ],
    assistiveTools: [
      'Therapeutic red-filtered lenses that protect rod cells in bright daylight',
      'Digital magnifiers and high-contrast monochrome screen themes',
      'Voice-guided assistants and tactile labeling kits',
    ],
  },
  {
    id: 'glaucoma',
    name: 'Glaucoma',
    shortName: 'Glaucoma',
    category: 'Retina & Nerve',
    prevalence: '~80 million people worldwide',
    affectedPart: 'Optic Nerve',
    summary:
      'Often called the "silent thief of sight," glaucoma slowly damages the optic nerve—frequently linked to elevated fluid pressure inside the eye—erasing side vision before central sharpness fades.',
    howPeopleSee:
      'The center of the scene stays surprisingly clear at first, while outer edges dim and vanish into a narrowing dark tunnel—hiding curbs, doorways, and approaching pedestrians.',
    visualSigns: [
      'Gradual loss of peripheral (side, upper, and lower) vision',
      'Narrowing "tunnel vision" in advanced stages',
      'No early pain in the most common open-angle form',
    ],
    medicalTreatments: [
      'Daily prescription eye drops to lower intraocular pressure and protect remaining optic nerve fibers',
      'Laser trabeculoplasty (SLT) or minimally invasive glaucoma surgery (MIGS) when drops are not enough',
      'Strict adherence to pressure checkups every 3–6 months (damage cannot be reversed, only halted)',
    ],
    selfCareSteps: [
      'Never skip prescribed glaucoma eye drops—set daily phone alarms to keep pressure steady',
      'Consciously scan side-to-side by turning your head when crossing streets or navigating stairs',
      'Clear floor clutter and mark step edges with bright high-contrast tape',
    ],
    assistiveTools: [
      'Eye-drop bottle guide brackets for accurate single-hand dosing',
      'Orientation & mobility cane training for safe outdoor navigation',
      'Moderate-magnification devices (high zoom shrinks the field further)',
    ],
  },
  {
    id: 'amd',
    name: 'Age-Related Macular Degeneration (AMD)',
    shortName: 'Macular Degeneration',
    category: 'Retina & Nerve',
    prevalence: '~196 million people worldwide',
    affectedPart: 'Central Macula',
    summary:
      'Deterioration of the macula—the tiny central zone of the retina responsible for reading, recognizing faces, and seeing fine straight lines.',
    howPeopleSee:
      'Side vision remains intact so you can still walk around a room, but a blurry, wavy, or dark smudge sits directly over whatever you try to look at—like faces or book pages.',
    visualSigns: [
      'Blurred, faded, or dark blind spot (scotoma) in the center of sight',
      'Straight lines (doorframes, text lines) appear wavy or bent',
      'Peripheral side vision stays largely preserved',
    ],
    medicalTreatments: [
      'Regular anti-VEGF eye injections for Wet AMD to stop abnormal leaky blood vessels',
      'AREDS2 nutritional supplement formula (prescribed for intermediate Dry AMD to slow progression)',
      'Daily home Amsler grid checks to catch sudden waviness immediately',
    ],
    selfCareSteps: [
      'Practice "eccentric viewing"—looking slightly above or beside an object to use healthy peripheral retina',
      'Place bright gooseneck lamps close to reading material and avoid glossy paper',
      'Use bold black felt-tip pens on unlined white or yellow pads',
    ],
    assistiveTools: [
      'Electronic video magnifiers (CCTV) with inverted white-on-black mode',
      'Screen readers (VoiceOver / TalkBack) and audiobooks',
      'Talking watches, kitchen scales, and glucose meters',
    ],
  },
  {
    id: 'diabetic-retinopathy',
    name: 'Diabetic Retinopathy',
    shortName: 'Diabetic Retinopathy',
    category: 'Retina & Nerve',
    prevalence: '~103 million adults with diabetes',
    affectedPart: 'Retinal Blood Vessels',
    summary:
      'High blood sugar weakens tiny blood vessels inside the retina, causing them to leak fluid, swell the macula, or bleed into the clear gel of the eye.',
    howPeopleSee:
      'Patchy dark spots, cobweb-like floaters, and blurred islands drift across the view, while fluctuating blood sugar can make focus shift from morning to evening.',
    visualSigns: [
      'Scattered dark blotches or cobweb-like floaters',
      'Patchy blurred areas across both central and side vision',
      'Day-to-day changes in sharpness as blood sugar fluctuates',
    ],
    medicalTreatments: [
      'Tight management of blood glucose (HbA1c), blood pressure, and cholesterol with your physician',
      'Anti-VEGF injections to reduce retinal swelling and fragile new vessel growth',
      'Laser photocoagulation or vitrectomy surgery to seal leaking vessels or clear blood',
    ],
    selfCareSteps: [
      'Never miss an annual dilated retinal exam—early stages have zero noticeable symptoms',
      'Keep indoor walkways evenly lit without harsh shadows where dark blotches hide obstacles',
      'Seek same-day care if you suddenly see new floaters, flashing lights, or a dark curtain',
    ],
    assistiveTools: [
      'Talking continuous glucose monitors (CGMs) and audio insulin pens',
      'Smartphone magnification and screen-reading tools',
      'High-contrast cutting boards and tactile appliance markers',
    ],
  },
  {
    id: 'retinitis-pigmentosa',
    name: 'Retinitis Pigmentosa (RP)',
    shortName: 'Retinitis Pigmentosa',
    category: 'Retina & Nerve',
    prevalence: '~1 in 4,000 people',
    affectedPart: 'Rod & Cone Photoreceptors',
    summary:
      'A group of inherited retinal conditions that gradually break down rod photoreceptors first, followed later by cone cells.',
    howPeopleSee:
      'Dusk, dimly lit restaurants, and night streets become nearly impossible to navigate (night blindness), while daylight vision slowly narrows into a crisp but very small central pinhole.',
    visualSigns: [
      'Severe difficulty seeing in dim light or at dusk (night blindness)',
      'Progressive concentric narrowing to a small central keyhole',
      'Slow adaptation moving from bright outdoors into dim rooms',
    ],
    medicalTreatments: [
      'Genetic testing with a retinal specialist to identify exact gene variants and eligibility for targeted gene therapies',
      'Regular monitoring for treatable secondary issues such as cataracts or macular swelling',
      'Low-vision rehabilitation and specialist optical prescribing',
    ],
    selfCareSteps: [
      'Carry a bright, wide-beam pocket flashlight or headlamp whenever going out near dusk',
      'Install motion-activated nightlights along hallways, bathrooms, and staircases',
      'Pause inside building entryways for 1–2 minutes to let your eyes adjust to indoor lighting',
    ],
    assistiveTools: [
      'Night-vision enhancement glasses and wide-beam LED torches',
      'White cane and orientation & mobility training before dusk becomes hazardous',
      'UV-blocking amber wraparound shields to protect remaining photoreceptors',
    ],
  },
];

export interface PreventionPillar {
  number: string;
  title: string;
  summary: string;
  actionItems: string[];
}

export const PREVENTION_PILLARS: PreventionPillar[] = [
  {
    number: '01',
    title: 'Comprehensive Dilated Eye Exams',
    summary:
      'Many sight-threatening conditions—including glaucoma, diabetic retinopathy, and early macular degeneration—cause zero pain or early symptoms.',
    actionItems: [
      'Only a dilated exam lets an eye doctor inspect your retina and optic nerve directly.',
      'Share any family history of glaucoma, retinal detachment, or macular degeneration.',
    ],
  },
  {
    number: '02',
    title: '100% UV Protection & Physical Safety',
    summary:
      'Ultraviolet sunlight accelerates cataracts and retinal stress, while eye trauma remains one of the most preventable causes of sudden blindness.',
    actionItems: [
      'Wear sunglasses labeled 100% UVA/UVB or UV400—even on hazy overcast days.',
      'Use ANSI-rated protective goggles when mowing, hammering, using chemicals, or playing high-speed sports.',
    ],
  },
  {
    number: '03',
    title: 'Control Blood Sugar, Pressure & Lipids',
    summary:
      'The retina contains the body’s finest blood vessels; metabolic and cardiovascular health directly protects your sight.',
    actionItems: [
      'Keep HbA1c, blood pressure, and cholesterol within targets set by your doctor.',
      'Diabetic retinopathy is over 90% preventable against severe vision loss with early screening and steady control.',
    ],
  },
  {
    number: '04',
    title: 'Nourish Your Retina Through Whole Foods',
    summary:
      'Specific plant pigments and fatty acids concentrate naturally inside the macula to filter harsh light and fight oxidative stress.',
    actionItems: [
      'Eat dark leafy greens (spinach, kale, collards) rich in lutein and zeaxanthin.',
      'Include omega-3 fatty fish, brightly colored peppers, berries, citrus, and zinc-rich nuts or legumes.',
    ],
  },
  {
    number: '05',
    title: 'Stop Smoking & Rest Digital Eyes',
    summary:
      'Smoking doubles or triples the risk of age-related macular degeneration and accelerates cataracts.',
    actionItems: [
      'Quitting tobacco at any age measurably lowers future retinal risk.',
      'Follow the 20-20-20 rule on screens: every 20 minutes, look 20 feet away for 20 seconds and blink fully.',
    ],
  },
  {
    number: '06',
    title: 'Act Immediately on Red-Flag Symptoms',
    summary:
      'Some emergencies—like retinal detachment or acute angle-closure glaucoma—can permanently damage vision within hours if untreated.',
    actionItems: [
      'Seek same-day emergency eye care for sudden flashes of light, a shower of new floaters, or a dark curtain moving across your view.',
      'Seek urgent care for sudden eye pain, severe redness with nausea, or abrupt vision loss in one eye.',
    ],
  },
];

export interface ExamScheduleTier {
  id: string;
  label: string;
  frequency: string;
  details: string;
  focusChecks: string[];
}

export const EXAM_SCHEDULE_TIERS: ExamScheduleTier[] = [
  {
    id: 'under-40',
    label: 'Ages 18–39 (Healthy)',
    frequency: 'Every 2 Years',
    details: 'Baseline dilated eye exam to verify refractive accuracy, retinal health, and eye pressure.',
    focusChecks: ['Visual acuity & refraction', 'Intraocular pressure baseline', 'Corneal & retinal inspection'],
  },
  {
    id: '40-64',
    label: 'Ages 40–64',
    frequency: 'Every 1–2 Years',
    details: 'Early screening catches presbyopia, emerging cataracts, and silent optic nerve pressure shifts.',
    focusChecks: ['Dilated optic nerve exam', 'Early lens clarity check', 'Peripheral field screening'],
  },
  {
    id: '65-plus',
    label: 'Ages 65 & Older',
    frequency: 'Every Year',
    details: 'Annual dilated exams detect age-related macular degeneration, cataracts, and glaucoma before daily function is affected.',
    focusChecks: ['Macular OCT scan', 'Cataract progression check', 'Glaucoma pressure & nerve check'],
  },
  {
    id: 'high-risk',
    label: 'Diabetes or Family History',
    frequency: 'Annually (or More Often)',
    details: 'People with Type 1 or Type 2 diabetes, high myopia, or a family history of glaucoma need yearly dilated exams regardless of age.',
    focusChecks: ['Retinal blood vessel photography', 'Macular fluid screening', 'Optic nerve fiber thickness'],
  },
];
