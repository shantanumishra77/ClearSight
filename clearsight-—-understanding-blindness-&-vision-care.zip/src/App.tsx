import { useState } from 'react';
import { MotionConfig, motion, useScroll, useSpring } from 'motion/react';
import type { VisionConditionId } from './data/visionData';
import { VisionFilterDefs } from './components/VisionFilterDefs';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { WhatIsBlindnessSection } from './components/WhatIsBlindnessSection';
import { VarietiesSection } from './components/VarietiesSection';
import { VisionSimulatorSection } from './components/VisionSimulatorSection';
import { TreatmentCareSection } from './components/TreatmentCareSection';
import { PreventionSection } from './components/PreventionSection';
import { Footer } from './components/Footer';

export default function App() {
  const [selectedCondition, setSelectedCondition] =
    useState<VisionConditionId>('cataracts');

  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 180,
    damping: 30,
    restDelta: 0.001,
  });

  const handleJumpToSimulator = (id: VisionConditionId) => {
    setSelectedCondition(id);
    document
      .getElementById('how-people-see')
      ?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const handleJumpToTreatment = (id: VisionConditionId) => {
    setSelectedCondition(id);
    document
      .getElementById('treatment')
      ?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
        {/* Subtle reading progress indicator */}
        <motion.div
          aria-hidden="true"
          className="fixed top-0 left-0 right-0 h-0.5 bg-sky-700 origin-left z-50 pointer-events-none"
          style={{ scaleX }}
        />

        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:px-4 focus:py-2 focus:bg-sky-700 focus:text-white focus:rounded-lg focus:text-sm focus:font-medium"
        >
          Skip to main content
        </a>

        <VisionFilterDefs />
        <Header />

        <main id="main-content" className="flex-1">
          <HeroBanner />
          <WhatIsBlindnessSection />
          <VarietiesSection
            onSimulateCondition={handleJumpToSimulator}
            onSelectTreatment={handleJumpToTreatment}
          />
          <VisionSimulatorSection
            selectedCondition={selectedCondition}
            onChangeCondition={setSelectedCondition}
          />
          <TreatmentCareSection
            selectedCondition={selectedCondition}
            onSelectCondition={setSelectedCondition}
          />
          <PreventionSection />
        </main>

        <Footer />
      </div>
    </MotionConfig>
  );
}
