import { useState, type CSSProperties } from 'react';
import { Eye } from 'lucide-react';

interface ResilientImageProps {
  src: string;
  alt: string;
  className?: string;
  style?: CSSProperties;
  fallbackTitle?: string;
}

export function ResilientImage({
  src,
  alt,
  className = '',
  style,
  fallbackTitle,
}: ResilientImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-slate-200 via-slate-100 to-sky-100 text-slate-700 p-6 text-center ${className}`}
        style={style}
      >
        <Eye className="w-8 h-8 text-sky-700 mb-2" aria-hidden="true" />
        <p className="text-sm font-medium text-slate-800 max-w-xs">
          {fallbackTitle || alt}
        </p>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
      style={style}
    />
  );
}
