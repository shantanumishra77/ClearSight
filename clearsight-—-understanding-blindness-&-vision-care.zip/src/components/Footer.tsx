export function Footer() {
  return (
    <footer className="bg-white py-12 text-slate-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-8 border-b border-slate-200">
          <div className="md:col-span-5 space-y-2.5">
            <a
              href="#banner"
              className="font-display text-xl font-semibold text-slate-900 inline-block"
            >
              ClearSight
            </a>
            <p className="text-sm text-slate-600 leading-relaxed max-w-md">
              An accessible educational resource explaining blindness, eye conditions, visual simulations, daily low-vision self-care, and lifelong vision protection.
            </p>
          </div>

          <div className="md:col-span-3 space-y-2.5">
            <p className="text-sm font-semibold text-slate-900">Sections</p>
            <ul className="space-y-1.5 text-sm">
              <li>
                <a href="#what-is-blindness" className="hover:text-slate-900 hover:underline">
                  What Is Blindness
                </a>
              </li>
              <li>
                <a href="#varieties" className="hover:text-slate-900 hover:underline">
                  Varieties of Blindness
                </a>
              </li>
              <li>
                <a href="#how-people-see" className="hover:text-slate-900 hover:underline">
                  How People See
                </a>
              </li>
              <li>
                <a href="#treatment" className="hover:text-slate-900 hover:underline">
                  Treatment &amp; Self-Care
                </a>
              </li>
              <li>
                <a href="#prevention" className="hover:text-slate-900 hover:underline">
                  Prevention
                </a>
              </li>
            </ul>
          </div>

          <div className="md:col-span-4 space-y-2.5">
            <p className="text-sm font-semibold text-slate-900">Medical Notice</p>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Visual simulations approximate common optical experiences for awareness and empathy; individual vision varies. Always consult a licensed optometrist or ophthalmologist for clinical eye exams and treatment.
            </p>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-slate-500">
          <p>ClearSight Educational Guide · Built for mobile &amp; desktop accessibility</p>
          <a
            href="#banner"
            className="font-medium text-slate-700 hover:text-slate-950 hover:underline"
          >
            Back to top
          </a>
        </div>
      </div>
    </footer>
  );
}
