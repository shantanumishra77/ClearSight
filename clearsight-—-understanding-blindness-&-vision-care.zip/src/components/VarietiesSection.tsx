import { useState } from 'react';
import { Eye, HeartHandshake } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import {
  VISION_CONDITIONS,
  type VarietyCategory,
  type VisionConditionId,
} from '../data/visionData';

interface VarietiesSectionProps {
  onSimulateCondition: (id: VisionConditionId) => void;
  onSelectTreatment: (id: VisionConditionId) => void;
}

const CATEGORIES: VarietyCategory[] = [
  'All',
  'Lens & Cornea',
  'Color Vision',
  'Retina & Nerve',
];

const EASE_OUT = [0.16, 1, 0.3, 1] as const;

export function VarietiesSection({
  onSimulateCondition,
  onSelectTreatment,
}: VarietiesSectionProps) {
  const [activeCategory, setActiveCategory] = useState<VarietyCategory>('All');

  const filteredConditions =
    activeCategory === 'All'
      ? VISION_CONDITIONS
      : VISION_CONDITIONS.filter((c) => c.category === activeCategory);

  return (
    <section
      id="varieties"
      aria-labelledby="varieties-heading"
      className="py-14 sm:py-20 bg-white border-b border-slate-200"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 'some' }}
            transition={{ duration: 0.4, ease: EASE_OUT }}
            className="max-w-2xl"
          >
            <p className="text-sm font-medium text-sky-700 mb-2">
              Types &amp; Conditions
            </p>
            <h2
              id="varieties-heading"
              className="font-display text-3xl sm:text-4xl font-semibold text-slate-900 tracking-tight mb-3"
              style={{ textWrap: 'balance' }}
            >
              Major varieties of blindness &amp; color vision loss
            </h2>
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
              Different eye conditions alter clarity, color, central focus, or side awareness in distinct ways. Select a category below or jump directly into a visual simulation.
            </p>
          </motion.div>

          {/* Interactive Filter Segmented Control with spring layout pill */}
          <div
            role="tablist"
            aria-label="Filter blindness varieties by category"
            className="inline-flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg self-start lg:self-auto"
          >
            {CATEGORIES.map((category) => {
              const isSelected = activeCategory === category;
              return (
                <button
                  key={category}
                  type="button"
                  role="tab"
                  aria-selected={isSelected}
                  onClick={() => setActiveCategory(category)}
                  className={`relative px-3.5 py-2 text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 min-h-[40px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-700 ${
                    isSelected
                      ? 'text-slate-950'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {isSelected && (
                    <motion.span
                      layoutId="varieties-active-tab"
                      transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                      className="absolute inset-0 bg-white rounded-md shadow-sm"
                    />
                  )}
                  <span className="relative z-10">{category}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Variety Cards Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          <AnimatePresence mode="popLayout">
            {filteredConditions.map((condition) => (
              <motion.article
                layout
                key={condition.id}
                initial={{ opacity: 0, scale: 0.96, y: 8 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.96, y: -6 }}
                transition={{ duration: 0.24, ease: EASE_OUT }}
                whileHover={{ y: -3 }}
                className="bg-slate-50 border border-slate-200 rounded-xl p-6 flex flex-col justify-between transition-shadow hover:border-slate-300 hover:shadow-sm"
              >
                <div>
                  {/* Clean unboxed inline metadata */}
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mb-3">
                    <span className="font-medium text-sky-800">{condition.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>{condition.affectedPart}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono-tabular">{condition.prevalence}</span>
                  </div>

                  <h3 className="text-xl font-semibold text-slate-900 mb-2.5 leading-snug">
                    {condition.name}
                  </h3>

                  <p className="text-sm text-slate-700 leading-relaxed mb-4">
                    {condition.summary}
                  </p>

                  <div className="border-t border-slate-200 pt-4 mb-5">
                    <p className="text-xs font-semibold text-slate-900 mb-2">
                      Key Visual Changes
                    </p>
                    <ul className="space-y-1.5 text-sm text-slate-600">
                      {condition.visualSigns.map((sign) => (
                        <li key={sign} className="leading-snug">
                          • {sign}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2.5 pt-2">
                  <motion.button
                    whileTap={{ scale: 0.97 }}
                    type="button"
                    onClick={() => onSimulateCondition(condition.id)}
                    className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 text-sm font-medium text-white bg-sky-700 rounded-lg hover:bg-sky-800 transition-colors min-h-[44px] whitespace-nowrap shrink-0 flex-1 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-700"
                  >
                    <Eye className="w-4 h-4" aria-hidden="true" />
                    <span>See How It Looks</span>
                  </motion.button>

                  <motion.button
                    whileTap={{ scale: 0.97 }}
                    type="button"
                    onClick={() => onSelectTreatment(condition.id)}
                    className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 text-sm font-medium text-slate-800 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition-colors min-h-[44px] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-700"
                  >
                    <HeartHandshake className="w-4 h-4" aria-hidden="true" />
                    <span>Self-Care</span>
                  </motion.button>
                </div>
              </motion.article>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
}
