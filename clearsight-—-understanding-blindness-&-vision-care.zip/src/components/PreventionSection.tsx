import { useState } from 'react';
import { Check, RotateCcw } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import {
  EYE_CARE_IMAGE,
  EXAM_SCHEDULE_TIERS,
  PREVENTION_PILLARS,
} from '../data/visionData';
import { ResilientImage } from './ResilientImage';

const DAILY_HABITS = [
  {
    id: 'sunglasses',
    text: 'Wear 100% UVA/UVB (UV400) sunglasses outdoors, even on cloudy days.',
  },
  {
    id: '20-20-20',
    text: 'Take a 20-second break looking 20 feet away every 20 minutes on screens.',
  },
  {
    id: 'greens',
    text: 'Include leafy greens (spinach, kale) or omega-3 rich foods in meals.',
  },
  {
    id: 'safety',
    text: 'Keep protective safety goggles accessible for yardwork, tools, or cleaning sprays.',
  },
  {
    id: 'chronic',
    text: 'Monitor blood sugar, blood pressure, and cholesterol as advised by your doctor.',
  },
  {
    id: 'exam',
    text: 'Keep your next comprehensive dilated eye exam scheduled on your calendar.',
  },
];

const EASE_OUT = [0.16, 1, 0.3, 1] as const;

export function PreventionSection() {
  const [selectedTierId, setSelectedTierId] = useState<string>(EXAM_SCHEDULE_TIERS[1].id);
  const [checkedHabits, setCheckedHabits] = useState<string[]>(['sunglasses']);

  const activeTier =
    EXAM_SCHEDULE_TIERS.find((t) => t.id === selectedTierId) || EXAM_SCHEDULE_TIERS[0];

  const toggleHabit = (id: string) => {
    setCheckedHabits((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const progressRatio = checkedHabits.length / DAILY_HABITS.length;

  return (
    <section
      id="prevention"
      aria-labelledby="prevention-heading"
      className="py-14 sm:py-20 bg-slate-50 border-b border-slate-200"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Split: Prevention Lead + Clinical Exam Photo */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch mb-12">
          <div className="lg:col-span-6 flex flex-col justify-center">
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 'some' }}
              transition={{ duration: 0.4, ease: EASE_OUT }}
            >
              <p className="text-sm font-medium text-sky-700 mb-2">
                Prevention &amp; Lifelong Protection
              </p>
              <h2
                id="prevention-heading"
                className="font-display text-3xl sm:text-4xl font-semibold text-slate-900 tracking-tight mb-4"
                style={{ textWrap: 'balance' }}
              >
                How to protect your sight &amp; prevent blindness
              </h2>
              <p className="text-base sm:text-lg text-slate-700 leading-relaxed mb-6">
                Over half of global vision impairment is preventable or treatable when caught early. Consistent dilated eye check-ups, UV and impact protection, and steady management of chronic conditions like diabetes shield your optic nerve and retina for life.
              </p>
            </motion.div>

            {/* Interactive Exam Frequency Checker */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6">
              <p className="text-xs font-semibold text-slate-500 mb-2.5">
                Check recommended dilated eye exam frequency
              </p>
              <div
                role="tablist"
                aria-label="Age and health risk category"
                className="flex flex-wrap gap-1.5 mb-4"
              >
                {EXAM_SCHEDULE_TIERS.map((tier) => {
                  const isActive = tier.id === selectedTierId;
                  return (
                    <button
                      key={tier.id}
                      type="button"
                      role="tab"
                      aria-selected={isActive}
                      onClick={() => setSelectedTierId(tier.id)}
                      className={`relative px-3 py-2 text-xs sm:text-sm font-medium rounded-lg border transition-colors min-h-[40px] whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-700 ${
                        isActive
                          ? 'text-white border-sky-700'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {isActive && (
                        <motion.span
                          layoutId="exam-tier-active-tab"
                          transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                          className="absolute inset-0 bg-sky-700 rounded-lg"
                        />
                      )}
                      <span className="relative z-10">{tier.label}</span>
                    </button>
                  );
                })}
              </div>

              <div className="border-t border-slate-200 pt-4 min-h-[108px]">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeTier.id}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    transition={{ duration: 0.18, ease: EASE_OUT }}
                    className="space-y-2"
                  >
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <span className="text-sm font-semibold text-slate-900">
                        Recommended Schedule
                      </span>
                      <span className="font-mono-tabular text-sm font-semibold text-sky-700">
                        {activeTier.frequency}
                      </span>
                    </div>
                    <p className="text-sm text-slate-600 leading-relaxed">
                      {activeTier.details}
                    </p>
                    <p className="text-xs text-slate-500 pt-1">
                      Key checks: {activeTier.focusChecks.join(' · ')}
                    </p>
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, amount: 'some' }}
            transition={{ duration: 0.45, ease: EASE_OUT }}
            className="lg:col-span-6"
          >
            <div className="h-full min-h-[280px] sm:min-h-[360px] rounded-xl overflow-hidden border border-slate-200 bg-white">
              <ResilientImage
                src={EYE_CARE_IMAGE}
                alt="An eye care specialist performing a reassuring, routine optical eye examination with a patient in a bright sunlit clinic"
                fallbackTitle="Routine Dilated Eye Examination"
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>
        </div>

        {/* 6 Evidence-Based Prevention Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {PREVENTION_PILLARS.map((pillar, idx) => (
            <motion.article
              key={pillar.number}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 'some' }}
              transition={{ duration: 0.34, delay: idx * 0.04, ease: EASE_OUT }}
              whileHover={{ y: -3 }}
              className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between transition-shadow hover:shadow-sm"
            >
              <div>
                <h3 className="text-lg font-semibold text-slate-900 mb-2.5">
                  <span className="font-mono-tabular text-sky-700 mr-2">
                    {pillar.number}.
                  </span>
                  {pillar.title}
                </h3>
                <p className="text-sm text-slate-700 leading-relaxed mb-4">
                  {pillar.summary}
                </p>
              </div>
              <ul className="border-t border-slate-200 pt-3.5 space-y-2 text-sm text-slate-600">
                {pillar.actionItems.map((action) => (
                  <li key={action} className="leading-snug">
                    • {action}
                  </li>
                ))}
              </ul>
            </motion.article>
          ))}
        </div>

        {/* Interactive Daily Eye-Health Habit Checklist */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
            <div>
              <h3 className="text-xl font-semibold text-slate-900">
                Daily Vision-Protection Checklist
              </h3>
              <p className="text-sm text-slate-600 mt-1">
                Track simple everyday habits that safeguard long-term retinal and lens health.
              </p>
            </div>
            <div className="flex items-center gap-4 shrink-0">
              <span className="font-mono-tabular text-sm font-medium text-sky-800">
                {checkedHabits.length} of {DAILY_HABITS.length} practiced
              </span>
              <motion.button
                whileTap={{ scale: 0.96 }}
                type="button"
                onClick={() => setCheckedHabits([])}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors min-h-[40px] whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-700"
              >
                <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Reset</span>
              </motion.button>
            </div>
          </div>

          {/* Smooth GPU scaleX progress bar */}
          <div
            aria-hidden="true"
            className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden mb-6"
          >
            <motion.div
              className="h-full bg-sky-700 origin-left"
              initial={false}
              animate={{ scaleX: progressRatio }}
              transition={{ type: 'spring', stiffness: 260, damping: 28 }}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {DAILY_HABITS.map((habit) => {
              const isChecked = checkedHabits.includes(habit.id);
              return (
                <motion.button
                  key={habit.id}
                  type="button"
                  role="checkbox"
                  aria-checked={isChecked}
                  whileTap={{ scale: 0.99 }}
                  onClick={() => toggleHabit(habit.id)}
                  className={`flex items-start gap-3.5 p-4 text-left rounded-lg border transition-colors min-h-[56px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-700 ${
                    isChecked
                      ? 'bg-sky-50/70 border-sky-700/40 text-slate-900'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span
                    aria-hidden="true"
                    className={`mt-0.5 w-5 h-5 rounded flex items-center justify-center shrink-0 border transition-colors ${
                      isChecked
                        ? 'bg-sky-700 border-sky-700 text-white'
                        : 'bg-white border-slate-300'
                    }`}
                  >
                    <AnimatePresence>
                      {isChecked && (
                        <motion.span
                          initial={{ scale: 0.4, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          exit={{ scale: 0.4, opacity: 0 }}
                          transition={{ type: 'spring', stiffness: 500, damping: 25 }}
                        >
                          <Check className="w-3.5 h-3.5" />
                        </motion.span>
                      )}
                    </AnimatePresence>
                  </span>
                  <span className="text-sm leading-relaxed">{habit.text}</span>
                </motion.button>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
