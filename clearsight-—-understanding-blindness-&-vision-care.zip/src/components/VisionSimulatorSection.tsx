import { useEffect, useState, type PointerEvent } from 'react';
import { Columns2, SlidersHorizontal, MoveHorizontal, Play, Pause } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import {
  SCENE_ASSETS,
  VISION_CONDITIONS,
  type VisionConditionId,
} from '../data/visionData';
import { SimulatedSceneImage } from './VisionFilterDefs';

interface VisionSimulatorSectionProps {
  selectedCondition: VisionConditionId;
  onChangeCondition: (id: VisionConditionId) => void;
}

const GALLERY_CONDITIONS: VisionConditionId[] = [
  'normal',
  'cataracts',
  'deuteranopia',
  'tritanopia',
  'glaucoma',
  'amd',
  'diabetic-retinopathy',
  'retinitis-pigmentosa',
];

const EASE_OUT = [0.16, 1, 0.3, 1] as const;

export function VisionSimulatorSection({
  selectedCondition,
  onChangeCondition,
}: VisionSimulatorSectionProps) {
  const [selectedSceneId, setSelectedSceneId] = useState<string>(SCENE_ASSETS[0].id);
  const [severity, setSeverity] = useState<number>(85);
  const [compareMode, setCompareMode] = useState<'split' | 'side-by-side'>('split');
  const [splitPercent, setSplitPercent] = useState<number>(50);
  const [isDragging, setIsDragging] = useState(false);
  const [isAutoScanning, setIsAutoScanning] = useState(false);

  const activeScene =
    SCENE_ASSETS.find((s) => s.id === selectedSceneId) || SCENE_ASSETS[0];

  const activeConditionInfo =
    VISION_CONDITIONS.find((c) => c.id === selectedCondition) || null;

  // Smooth optional Auto-Scan animation sweeping the comparison wipe back and forth
  useEffect(() => {
    if (!isAutoScanning || compareMode !== 'split' || isDragging) return;
    let rafId = 0;
    const start = performance.now();
    const initialPhase = Math.asin(Math.max(-1, Math.min(1, (splitPercent - 50) / 36)));

    const step = (now: number) => {
      const elapsed = (now - start) / 1000;
      const next = Math.round(50 + Math.sin(elapsed * 1.15 + initialPhase) * 36);
      setSplitPercent(next);
      rafId = requestAnimationFrame(step);
    };

    rafId = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafId);
  }, [isAutoScanning, compareMode, isDragging]);

  const updateSplitFromPointer = (clientX: number, rect: DOMRect) => {
    const raw = ((clientX - rect.left) / rect.width) * 100;
    const clamped = Math.max(8, Math.min(92, Math.round(raw)));
    setSplitPercent(clamped);
  };

  const handlePointerDown = (e: PointerEvent<HTMLDivElement>) => {
    setIsAutoScanning(false);
    setIsDragging(true);
    e.currentTarget.setPointerCapture(e.pointerId);
    updateSplitFromPointer(e.clientX, e.currentTarget.getBoundingClientRect());
  };

  const handlePointerMove = (e: PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    updateSplitFromPointer(e.clientX, e.currentTarget.getBoundingClientRect());
  };

  const handlePointerUp = (e: PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    setIsDragging(false);
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
  };

  const getSeverityStageLabel = (val: number) => {
    if (val <= 40) return 'Mild';
    if (val <= 75) return 'Moderate';
    return 'Advanced';
  };

  return (
    <section
      id="how-people-see"
      aria-labelledby="simulator-heading"
      className="py-14 sm:py-20 bg-slate-50 border-b border-slate-200"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 'some' }}
          transition={{ duration: 0.4, ease: EASE_OUT }}
          className="max-w-3xl mb-10"
        >
          <p className="text-sm font-medium text-sky-700 mb-2">
            Interactive Photo Comparison
          </p>
          <h2
            id="simulator-heading"
            className="font-display text-3xl sm:text-4xl font-semibold text-slate-900 tracking-tight mb-3"
            style={{ textWrap: 'balance' }}
          >
            Photos of how people see in different blindness
          </h2>
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            Compare typical sight against simulated views of cataracts, color blindness, glaucoma, macular degeneration, diabetic retinopathy, and retinitis pigmentosa on real photographs.
          </p>
        </motion.div>

        {/* Two-Zone Interactive Sandbox Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-16">
          {/* Left / Top Zone: Interactive Photographic Stage */}
          <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-4 sm:p-6">
            {/* Stage Toolbar: Scene Selector & View Mode Toggle */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5">
              <div className="flex flex-wrap gap-1.5" role="group" aria-label="Choose reference photograph">
                {SCENE_ASSETS.map((scene) => {
                  const isActive = scene.id === selectedSceneId;
                  return (
                    <button
                      key={scene.id}
                      type="button"
                      onClick={() => setSelectedSceneId(scene.id)}
                      className={`px-3 py-2 text-xs sm:text-sm font-medium rounded-lg border transition-colors min-h-[40px] whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-700 ${
                        isActive
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {scene.title}
                    </button>
                  );
                })}
              </div>

              {/* View Mode Switch */}
              <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start sm:self-auto shrink-0">
                <button
                  type="button"
                  onClick={() => setCompareMode('split')}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap min-h-[36px] ${
                    compareMode === 'split'
                      ? 'bg-white text-slate-950 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Split Wipe</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsAutoScanning(false);
                    setCompareMode('side-by-side');
                  }}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap min-h-[36px] ${
                    compareMode === 'side-by-side'
                      ? 'bg-white text-slate-950 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Columns2 className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Side by Side</span>
                </button>
              </div>
            </div>

            {/* Interactive Visual Stage with smooth mode & scene fade */}
            <AnimatePresence mode="wait">
              {compareMode === 'split' ? (
                <motion.div
                  key={`split-${activeScene.id}`}
                  initial={{ opacity: 0.35 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0.35 }}
                  transition={{ duration: 0.22 }}
                  className="space-y-4"
                >
                  <div
                    onPointerDown={handlePointerDown}
                    onPointerMove={handlePointerMove}
                    onPointerUp={handlePointerUp}
                    onPointerCancel={handlePointerUp}
                    role="img"
                    aria-label={`Interactive split comparison showing typical vision on the left and ${activeConditionInfo ? activeConditionInfo.name : 'normal vision'} on the right for ${activeScene.title}`}
                    className="relative aspect-[4/3] w-full rounded-lg overflow-hidden bg-slate-900 cursor-ew-resize touch-none"
                  >
                    {/* Full Right Side: Simulated Vision */}
                    <SimulatedSceneImage
                      src={activeScene.imageUrl}
                      alt={activeScene.alt}
                      condition={selectedCondition}
                      severity={severity / 100}
                      className="w-full h-full"
                    />

                    {/* Clipped Left Side: Typical Vision */}
                    <div
                      aria-hidden="true"
                      className="absolute inset-0 overflow-hidden"
                      style={{ clipPath: `inset(0 ${100 - splitPercent}% 0 0)` }}
                    >
                      <SimulatedSceneImage
                        src={activeScene.imageUrl}
                        alt=""
                        condition="normal"
                        severity={1}
                        className="w-full h-full"
                      />
                    </div>

                    {/* Labels */}
                    <div className="absolute top-3 left-3 px-2.5 py-1 bg-slate-950/80 text-white text-xs font-medium rounded pointer-events-none">
                      Typical Vision
                    </div>
                    <div className="absolute top-3 right-3 px-2.5 py-1 bg-slate-950/80 text-white text-xs font-medium rounded pointer-events-none">
                      {activeConditionInfo ? activeConditionInfo.shortName : 'Typical Vision'}
                    </div>

                    {/* Divider Handle */}
                    <div
                      aria-hidden="true"
                      className="absolute top-0 bottom-0 w-0.5 bg-white shadow-[0_0_8px_rgba(0,0,0,0.6)] pointer-events-none"
                      style={{ left: `${splitPercent}%` }}
                    >
                      <div className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white text-slate-900 shadow-lg border border-slate-200 flex items-center justify-center">
                        <MoveHorizontal className="w-5 h-5" />
                      </div>
                    </div>
                  </div>

                  {/* Accessible Keyboard Range Control & Auto-Scan Sweep Toggle */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                    <div className="flex items-center gap-3 flex-1 min-w-[200px]">
                      <label
                        htmlFor="split-wipe-slider"
                        className="text-xs font-medium text-slate-600 whitespace-nowrap"
                      >
                        Compare Wipe: <span className="font-mono-tabular text-slate-900">{splitPercent}%</span>
                      </label>
                      <input
                        id="split-wipe-slider"
                        type="range"
                        min={8}
                        max={92}
                        value={splitPercent}
                        onChange={(e) => {
                          setIsAutoScanning(false);
                          setSplitPercent(Number(e.target.value));
                        }}
                        className="vision-slider w-full max-w-xs"
                      />
                    </div>

                    <motion.button
                      whileTap={{ scale: 0.96 }}
                      type="button"
                      onClick={() => setIsAutoScanning((prev) => !prev)}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors min-h-[36px] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-700 ${
                        isAutoScanning
                          ? 'bg-sky-700 text-white border-sky-700'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {isAutoScanning ? (
                        <>
                          <Pause className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>Pause Auto-Scan</span>
                        </>
                      ) : (
                        <>
                          <Play className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>Play Auto-Scan</span>
                        </>
                      )}
                    </motion.button>
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key={`side-${activeScene.id}`}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.22 }}
                  className="grid grid-cols-1 sm:grid-cols-2 gap-4"
                >
                  <div>
                    <p className="text-xs font-semibold text-slate-700 mb-2">
                      Typical Vision
                    </p>
                    <SimulatedSceneImage
                      src={activeScene.imageUrl}
                      alt={`Typical vision view of ${activeScene.title}`}
                      condition="normal"
                      severity={1}
                      className="aspect-[4/3] w-full rounded-lg"
                    />
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-sky-800 mb-2">
                      {activeConditionInfo ? activeConditionInfo.name : 'Typical Vision'} ({getSeverityStageLabel(severity)})
                    </p>
                    <SimulatedSceneImage
                      src={activeScene.imageUrl}
                      alt={`Simulated ${activeConditionInfo ? activeConditionInfo.name : 'typical'} view of ${activeScene.title}`}
                      condition={selectedCondition}
                      severity={severity / 100}
                      className="aspect-[4/3] w-full rounded-lg"
                    />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <p className="mt-4 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-200 pt-3">
              <strong className="font-semibold text-slate-800">Why this photo matters: </strong>
              {activeScene.whyUseful}
            </p>
          </div>

          {/* Right / Bottom Zone: Condition Picker, Severity Slider & Annotation */}
          <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-6">
            <div>
              <h3 className="text-base font-semibold text-slate-900 mb-3">
                Select Vision Condition
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-2 gap-2">
                <motion.button
                  whileTap={{ scale: 0.97 }}
                  type="button"
                  onClick={() => onChangeCondition('normal')}
                  className={`px-3 py-2.5 text-left text-xs sm:text-sm font-medium rounded-lg border transition-colors min-h-[44px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-700 ${
                    selectedCondition === 'normal'
                      ? 'bg-sky-700 text-white border-sky-700'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  Typical Vision
                </motion.button>
                {VISION_CONDITIONS.map((cond) => {
                  const isActive = selectedCondition === cond.id;
                  return (
                    <motion.button
                      whileTap={{ scale: 0.97 }}
                      key={cond.id}
                      type="button"
                      onClick={() => onChangeCondition(cond.id)}
                      className={`px-3 py-2.5 text-left text-xs sm:text-sm font-medium rounded-lg border transition-colors min-h-[44px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-700 ${
                        isActive
                          ? 'bg-sky-700 text-white border-sky-700'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {cond.shortName}
                    </motion.button>
                  );
                })}
              </div>
            </div>

            {/* Severity Slider */}
            <div className="border-t border-slate-200 pt-5">
              <div className="flex items-center justify-between mb-2">
                <label
                  htmlFor="condition-severity-slider"
                  className="text-sm font-semibold text-slate-900"
                >
                  Condition Severity
                </label>
                <span className="font-mono-tabular text-sm font-medium text-sky-700">
                  {selectedCondition === 'normal'
                    ? '0% (Baseline)'
                    : `${severity}% · ${getSeverityStageLabel(severity)}`}
                </span>
              </div>
              <input
                id="condition-severity-slider"
                type="range"
                min={25}
                max={100}
                step={5}
                disabled={selectedCondition === 'normal'}
                value={severity}
                onChange={(e) => setSeverity(Number(e.target.value))}
                className="vision-slider w-full disabled:opacity-40"
              />
              <div className="flex justify-between text-xs text-slate-500 mt-1.5">
                <span>25% Mild</span>
                <span>60% Moderate</span>
                <span>100% Advanced</span>
              </div>
            </div>

            {/* Animated What-People-See Annotation */}
            <div className="border-t border-slate-200 pt-5 min-h-[112px]">
              <h4 className="text-sm font-semibold text-slate-900 mb-2">
                What a person sees
              </h4>
              <AnimatePresence mode="wait">
                <motion.div
                  key={selectedCondition}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -4 }}
                  transition={{ duration: 0.18, ease: EASE_OUT }}
                >
                  {activeConditionInfo ? (
                    <div className="space-y-2.5">
                      <p className="text-sm text-slate-700 leading-relaxed">
                        {activeConditionInfo.howPeopleSee}
                      </p>
                      <p className="text-xs text-slate-500">
                        Affected area: {activeConditionInfo.affectedPart}
                      </p>
                    </div>
                  ) : (
                    <p className="text-sm text-slate-700 leading-relaxed">
                      Clear 20/20 acuity with full trichromatic color perception (red, green, and blue cones functioning together) and complete central and peripheral awareness.
                    </p>
                  )}
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* Part B: Photo Comparison Gallery Across All Key Blindness Types */}
        <div className="pt-8 border-t border-slate-200">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div>
              <h3 className="font-display text-2xl sm:text-3xl font-semibold text-slate-900 mb-2">
                Side-by-side visual comparison gallery
              </h3>
              <p className="text-sm sm:text-base text-slate-600 max-w-2xl">
                Every photograph below uses the exact same {activeScene.title.toLowerCase()} scene so you can compare how each eye condition reshapes clarity, color, or visual field. Tap any photo to inspect it in the simulator above.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {GALLERY_CONDITIONS.map((condId, idx) => {
              const info = VISION_CONDITIONS.find((c) => c.id === condId);
              const title = info ? info.shortName : 'Typical Vision';
              const caption = info
                ? info.visualSigns[0]
                : 'Sharp central and peripheral sight with full natural color';
              const isSelected = selectedCondition === condId;

              return (
                <motion.button
                  key={condId}
                  type="button"
                  initial={{ opacity: 0, y: 12 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 'some' }}
                  transition={{ duration: 0.3, delay: idx * 0.04, ease: EASE_OUT }}
                  whileHover={{ y: -4 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    onChangeCondition(condId);
                    document
                      .getElementById('how-people-see')
                      ?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }}
                  className={`group text-left bg-white rounded-xl overflow-hidden border transition-shadow focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-700 ${
                    isSelected
                      ? 'border-sky-700 ring-2 ring-sky-700/20 shadow-sm'
                      : 'border-slate-200 hover:border-slate-300 hover:shadow-md'
                  }`}
                >
                  <SimulatedSceneImage
                    src={activeScene.imageUrl}
                    alt={`Photo comparison showing ${title} on ${activeScene.title}`}
                    condition={condId}
                    severity={0.85}
                    className="aspect-[4/3] w-full"
                  />
                  <div className="p-4">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <h4 className="text-base font-semibold text-slate-900 group-hover:text-sky-800 transition-colors">
                        {title}
                      </h4>
                      {isSelected && (
                        <span className="text-xs font-medium text-sky-700">
                          Active
                        </span>
                      )}
                    </div>
                    <p className="text-xs sm:text-sm text-slate-600 leading-snug">
                      {caption}
                    </p>
                  </div>
                </motion.button>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
