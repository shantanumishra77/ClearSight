import { Stethoscope, Home, Smartphone, AlertTriangle } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { VISION_CONDITIONS, type VisionConditionId } from '../data/visionData';

interface TreatmentCareSectionProps {
  selectedCondition: VisionConditionId;
  onSelectCondition: (id: VisionConditionId) => void;
}

const UNIVERSAL_SELF_CARE = [
  {
    title: 'Lighting Without Glare',
    detail:
      'Use warm, adjustable gooseneck task lamps aimed directly at books, stoves, or work surfaces while shading bare bulbs and glossy tabletops.',
  },
  {
    title: 'High Contrast & Tactile Markers',
    detail:
      'Place raised silicone bump dots on microwave buttons, stove dials, and thermostats; pair dark cutting boards for light foods (onions, rice) and white boards for dark foods.',
  },
  {
    title: 'Built-In Phone Accessibility',
    detail:
      'Enable VoiceOver (iOS) or TalkBack (Android), Magnification gestures, Display Zoom, and Color Filters—built free into every modern smartphone.',
  },
  {
    title: 'Safe, Clutter-Free Walkways',
    detail:
      'Secure loose rug edges, coil extension cords along walls, keep furniture in consistent spots, and mark step edges with high-contrast grip strips.',
  },
];

const EASE_OUT = [0.16, 1, 0.3, 1] as const;

export function TreatmentCareSection({
  selectedCondition,
  onSelectCondition,
}: TreatmentCareSectionProps) {
  const activeId: Exclude<VisionConditionId, 'normal'> =
    selectedCondition === 'normal' ? 'cataracts' : selectedCondition;

  const activeCondition =
    VISION_CONDITIONS.find((c) => c.id === activeId) || VISION_CONDITIONS[0];

  return (
    <section
      id="treatment"
      aria-labelledby="treatment-heading"
      className="py-14 sm:py-20 bg-white border-b border-slate-200"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 'some' }}
          transition={{ duration: 0.4, ease: EASE_OUT }}
          className="max-w-3xl mb-10"
        >
          <p className="text-sm font-medium text-sky-700 mb-2">
            Treatment &amp; Daily Self-Care
          </p>
          <h2
            id="treatment-heading"
            className="font-display text-3xl sm:text-4xl font-semibold text-slate-900 tracking-tight mb-3"
            style={{ textWrap: 'balance' }}
          >
            How to care for &amp; treat yourself with vision loss
          </h2>
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            Whether you live with treatable cataracts, color vision deficiency, glaucoma, or retinal vision loss, combining prompt medical care with practical home adaptations protects independence and comfort.
          </p>
        </motion.div>

        {/* Condition Selector Bar (mobile horizontal wrap, >=44px targets) */}
        <div className="mb-8">
          <p className="text-xs font-semibold text-slate-500 mb-2.5">
            Choose a condition for tailored treatment &amp; self-care guidance
          </p>
          <div
            role="tablist"
            aria-label="Select eye condition for treatment details"
            className="flex flex-wrap gap-2"
          >
            {VISION_CONDITIONS.map((cond) => {
              const isSelected = cond.id === activeCondition.id;
              return (
                <button
                  key={cond.id}
                  type="button"
                  role="tab"
                  aria-selected={isSelected}
                  onClick={() => onSelectCondition(cond.id)}
                  className={`relative px-3.5 py-2.5 text-sm font-medium rounded-lg border transition-colors min-h-[44px] whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-700 ${
                    isSelected
                      ? 'text-white border-sky-700'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  {isSelected && (
                    <motion.span
                      layoutId="treatment-active-tab"
                      transition={{ type: 'spring', stiffness: 380, damping: 32 }}
                      className="absolute inset-0 bg-sky-700 rounded-lg"
                    />
                  )}
                  <span className="relative z-10">{cond.shortName}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Animated Condition-Specific 3-Pillar Care Panel */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 sm:p-8 mb-10 overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeCondition.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.2, ease: EASE_OUT }}
            >
              <div className="flex flex-wrap items-baseline justify-between gap-4 pb-5 mb-6 border-b border-slate-200">
                <div>
                  <h3 className="font-display text-2xl sm:text-3xl font-semibold text-slate-900">
                    {activeCondition.name}
                  </h3>
                  <p className="text-sm text-slate-600 mt-1">
                    {activeCondition.category} · {activeCondition.affectedPart}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {/* Medical Care */}
                <div>
                  <div className="flex items-center gap-2 text-slate-900 font-semibold text-base mb-3">
                    <Stethoscope className="w-5 h-5 text-sky-700 shrink-0" aria-hidden="true" />
                    <h4>Medical Treatments</h4>
                  </div>
                  <ul className="space-y-3 text-sm text-slate-700 leading-relaxed">
                    {activeCondition.medicalTreatments.map((item) => (
                      <li key={item} className="pb-2.5 border-b border-slate-200/80 last:border-b-0 last:pb-0">
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Daily Self-Care */}
                <div>
                  <div className="flex items-center gap-2 text-slate-900 font-semibold text-base mb-3">
                    <Home className="w-5 h-5 text-sky-700 shrink-0" aria-hidden="true" />
                    <h4>Daily Self-Care Habits</h4>
                  </div>
                  <ul className="space-y-3 text-sm text-slate-700 leading-relaxed">
                    {activeCondition.selfCareSteps.map((item) => (
                      <li key={item} className="pb-2.5 border-b border-slate-200/80 last:border-b-0 last:pb-0">
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Assistive Tools */}
                <div>
                  <div className="flex items-center gap-2 text-slate-900 font-semibold text-base mb-3">
                    <Smartphone className="w-5 h-5 text-sky-700 shrink-0" aria-hidden="true" />
                    <h4>Helpful Assistive Tools</h4>
                  </div>
                  <ul className="space-y-3 text-sm text-slate-700 leading-relaxed">
                    {activeCondition.assistiveTools.map((item) => (
                      <li key={item} className="pb-2.5 border-b border-slate-200/80 last:border-b-0 last:pb-0">
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Universal Low-Vision & Home Adaptation Essentials */}
        <div className="mb-10">
          <h3 className="text-xl font-semibold text-slate-900 mb-5">
            Practical everyday adjustments for any visual impairment
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {UNIVERSAL_SELF_CARE.map((tip, idx) => (
              <motion.div
                key={tip.title}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 'some' }}
                transition={{ duration: 0.32, delay: idx * 0.05, ease: EASE_OUT }}
                whileHover={{ y: -2 }}
                className="bg-white border border-slate-200 rounded-xl p-5 transition-shadow hover:shadow-sm"
              >
                <h4 className="text-base font-semibold text-slate-900 mb-2">
                  {tip.title}
                </h4>
                <p className="text-sm text-slate-600 leading-relaxed">
                  {tip.detail}
                </p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Calm Medical Disclaimer & Urgent Symptom Notice */}
        <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-5 sm:p-6 flex flex-col sm:flex-row gap-4 items-start">
          <AlertTriangle
            className="w-5 h-5 text-amber-700 shrink-0 mt-0.5"
            aria-hidden="true"
          />
          <div className="space-y-1 text-sm text-slate-800 leading-relaxed">
            <p className="font-semibold text-slate-900">
              When to seek immediate eye care
            </p>
            <p>
              This guide is for education and daily self-care planning—it does not replace diagnosis or prescriptions from a licensed ophthalmologist or optometrist. Seek same-day emergency eye evaluation if you experience sudden vision loss, new flashing lights, a sudden shower of floaters, severe eye pain, or a dark shadow moving across your view.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
