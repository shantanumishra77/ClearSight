import { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { EYE_ANATOMY_PARTS, type EyePartInfo } from '../data/visionData';

const SPECTRUM_LEVELS = [
  {
    title: 'Mild to Moderate Low Vision',
    acuity: '20/40 to 20/70',
    description:
      'Small print, distant road signs, or low-light rooms feel strained even with standard eyeglasses, though daily independence remains high.',
  },
  {
    title: 'Severe Visual Impairment',
    acuity: '20/70 to 20/160',
    description:
      'Reading standard print requires strong magnification, high-contrast lighting, or audio tools, and recognizing faces across a room becomes difficult.',
  },
  {
    title: 'Legal Blindness',
    acuity: '20/200 or ≤ 20° field',
    description:
      'Defined clinically when best-corrected vision in the stronger eye is 20/200 or worse—or peripheral field narrows to 20 degrees or less. Most legally blind people still perceive light, shapes, or color.',
  },
  {
    title: 'Total Blindness (NLP)',
    acuity: 'No Light Perception',
    description:
      'Complete absence of visual light signal—accounting for roughly 10% to 15% of people classified as legally blind. Navigation relies on touch, sound, Braille, and mobility training.',
  },
];

const EASE_OUT = [0.16, 1, 0.3, 1] as const;

export function WhatIsBlindnessSection() {
  const [selectedPartId, setSelectedPartId] = useState<EyePartInfo['id']>('lens');

  const activePart =
    EYE_ANATOMY_PARTS.find((part) => part.id === selectedPartId) || EYE_ANATOMY_PARTS[0];

  return (
    <section
      id="what-is-blindness"
      aria-labelledby="what-is-blindness-heading"
      className="py-14 sm:py-20 bg-slate-50 border-b border-slate-200"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 'some' }}
          transition={{ duration: 0.4, ease: EASE_OUT }}
          className="max-w-3xl mb-10 sm:mb-12"
        >
          <p className="text-sm font-medium text-sky-700 mb-2">
            Understanding Vision Loss
          </p>
          <h2
            id="what-is-blindness-heading"
            className="font-display text-3xl sm:text-4xl font-semibold text-slate-900 tracking-tight mb-4"
            style={{ textWrap: 'balance' }}
          >
            What is blindness?
          </h2>
          <p className="text-base sm:text-lg text-slate-700 leading-relaxed">
            Blindness is the partial or complete inability to see clearly—even with standard eyeglasses, contact lenses, or medication. Rather than an all-or-nothing switch into pitch black, blindness spans a wide spectrum depending on which part of the eye or optic pathway is affected.
          </p>
        </motion.div>

        {/* Interactive Eye Anatomy Explorer + Clinical Spectrum */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left: Interactive Cross-Section Diagram */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
                <div>
                  <h3 className="text-lg font-semibold text-slate-900">
                    How the Eye Sees — Tap a Structure
                  </h3>
                  <p className="text-sm text-slate-600">
                    Select any part of the eye to learn what happens when it is damaged.
                  </p>
                </div>
              </div>

              {/* Part Selector Tabs with animated active indicator */}
              <div
                role="tablist"
                aria-label="Eye anatomy structures"
                className="flex flex-wrap gap-2 mb-6"
              >
                {EYE_ANATOMY_PARTS.map((part) => {
                  const isActive = part.id === selectedPartId;
                  return (
                    <button
                      key={part.id}
                      type="button"
                      role="tab"
                      aria-selected={isActive}
                      onClick={() => setSelectedPartId(part.id)}
                      className={`relative px-3.5 py-2 text-sm font-medium rounded-lg border transition-colors min-h-[40px] whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-700 ${
                        isActive
                          ? 'text-white border-sky-700'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100 hover:text-slate-900'
                      }`}
                    >
                      {isActive && (
                        <motion.span
                          layoutId="anatomy-active-tab"
                          transition={{ type: 'spring', stiffness: 380, damping: 32 }}
                          className="absolute inset-0 bg-sky-700 rounded-lg"
                        />
                      )}
                      <span className="relative z-10">{part.name}</span>
                    </button>
                  );
                })}
              </div>

              {/* Clean Interactive Eye Cross-Section SVG with animated photon & nerve pulses */}
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 sm:p-6 mb-6">
                <svg
                  viewBox="0 0 640 300"
                  role="img"
                  aria-label={`Cross-section diagram of the human eye highlighting the ${activePart.name}`}
                  className="w-full h-auto max-h-[250px]"
                >
                  {/* Incoming light rays */}
                  <line x1="25" y1="108" x2="196" y2="128" stroke="#0284c7" strokeWidth="1.5" strokeDasharray="5 5" opacity="0.45" />
                  <line x1="25" y1="150" x2="434" y2="150" stroke="#0284c7" strokeWidth="1.5" strokeDasharray="5 5" opacity="0.45" />
                  <line x1="25" y1="192" x2="196" y2="172" stroke="#0284c7" strokeWidth="1.5" strokeDasharray="5 5" opacity="0.45" />
                  {/* Converging focal rays from Lens to Macula */}
                  <line x1="196" y1="128" x2="434" y2="150" stroke="#0284c7" strokeWidth="1.5" strokeDasharray="4 4" opacity="0.35" />
                  <line x1="196" y1="172" x2="434" y2="150" stroke="#0284c7" strokeWidth="1.5" strokeDasharray="4 4" opacity="0.35" />
                  <text x="26" y="92" fill="#475569" fontSize="13" fontWeight="500">Incoming Light</text>

                  {/* Animated Photon Pulses traveling along center light beam */}
                  <motion.circle
                    r="3.5"
                    fill="#0284c7"
                    initial={{ cx: 25, cy: 150, opacity: 0 }}
                    animate={{
                      cx: [25, 196, 434],
                      cy: [150, 150, 150],
                      opacity: [0, 0.9, 0],
                    }}
                    transition={{
                      duration: 2.2,
                      repeat: Infinity,
                      ease: 'linear',
                    }}
                  />
                  <motion.circle
                    r="2.8"
                    fill="#38bdf8"
                    initial={{ cx: 25, cy: 108, opacity: 0 }}
                    animate={{
                      cx: [25, 196, 434],
                      cy: [108, 128, 150],
                      opacity: [0, 0.85, 0],
                    }}
                    transition={{
                      duration: 2.2,
                      delay: 0.7,
                      repeat: Infinity,
                      ease: 'linear',
                    }}
                  />
                  <motion.circle
                    r="2.8"
                    fill="#38bdf8"
                    initial={{ cx: 25, cy: 192, opacity: 0 }}
                    animate={{
                      cx: [25, 196, 434],
                      cy: [192, 172, 150],
                      opacity: [0, 0.85, 0],
                    }}
                    transition={{
                      duration: 2.2,
                      delay: 0.7,
                      repeat: Infinity,
                      ease: 'linear',
                    }}
                  />

                  {/* Outer Sclera Globe */}
                  <path
                    d="M 145 80 C 200 32, 360 32, 420 96 C 455 133, 455 167, 420 204 C 360 268, 200 268, 145 220"
                    fill="#ffffff"
                    stroke="#cbd5e1"
                    strokeWidth="6"
                  />

                  {/* Retina lining (inner back curve) */}
                  <path
                    d="M 235 55 C 325 46, 405 82, 426 130 M 426 170 C 405 218, 325 254, 235 245"
                    fill="none"
                    stroke={selectedPartId === 'retina' ? '#0369a1' : '#f59e0b'}
                    strokeWidth={selectedPartId === 'retina' ? '10' : '6'}
                    strokeLinecap="round"
                    className="cursor-pointer transition-all"
                    onClick={() => setSelectedPartId('retina')}
                  />
                  {/* Macula focal target */}
                  <circle
                    cx="434"
                    cy="150"
                    r={selectedPartId === 'retina' ? '12' : '9'}
                    fill={selectedPartId === 'retina' ? '#0369a1' : '#d97706'}
                    className="cursor-pointer transition-all"
                    onClick={() => setSelectedPartId('retina')}
                  />

                  {/* Optic Nerve exiting back right */}
                  <g
                    className="cursor-pointer"
                    onClick={() => setSelectedPartId('optic-nerve')}
                  >
                    <path
                      d="M 432 136 L 595 112 L 595 168 L 432 164 Z"
                      fill={selectedPartId === 'optic-nerve' ? '#0369a1' : '#e2e8f0'}
                      stroke={selectedPartId === 'optic-nerve' ? '#075985' : '#94a3b8'}
                      strokeWidth="2.5"
                    />
                    <line x1="448" y1="145" x2="585" y2="128" stroke={selectedPartId === 'optic-nerve' ? '#bae6fd' : '#cbd5e1'} strokeWidth="2" />
                    <line x1="448" y1="154" x2="585" y2="152" stroke={selectedPartId === 'optic-nerve' ? '#bae6fd' : '#cbd5e1'} strokeWidth="2" />
                    {/* Neural signal pulse traveling down optic nerve */}
                    <motion.circle
                      r="3"
                      fill={selectedPartId === 'optic-nerve' ? '#ffffff' : '#0284c7'}
                      animate={{
                        cx: [446, 588],
                        cy: [145, 128],
                        opacity: [0, 1, 0],
                      }}
                      transition={{
                        duration: 1.5,
                        repeat: Infinity,
                        ease: 'easeInOut',
                      }}
                    />
                  </g>

                  {/* Cornea (curved front dome) */}
                  <path
                    d="M 148 78 Q 92 150 148 222"
                    fill={selectedPartId === 'cornea' ? 'rgba(3, 105, 161, 0.2)' : 'rgba(186, 230, 253, 0.35)'}
                    stroke={selectedPartId === 'cornea' ? '#0369a1' : '#0284c7'}
                    strokeWidth={selectedPartId === 'cornea' ? '6' : '4'}
                    className="cursor-pointer transition-all"
                    onClick={() => setSelectedPartId('cornea')}
                  />

                  {/* Iris (upper and lower ring leaving pupil gap) */}
                  <g className="cursor-pointer" onClick={() => setSelectedPartId('iris')}>
                    <rect
                      x="160"
                      y="84"
                      width="12"
                      height="42"
                      rx="6"
                      fill={selectedPartId === 'iris' ? '#0369a1' : '#334155'}
                    />
                    <rect
                      x="160"
                      y="174"
                      width="12"
                      height="42"
                      rx="6"
                      fill={selectedPartId === 'iris' ? '#0369a1' : '#334155'}
                    />
                  </g>

                  {/* Natural Lens */}
                  <ellipse
                    cx="196"
                    cy="150"
                    rx="18"
                    ry="44"
                    fill={selectedPartId === 'lens' ? '#bae6fd' : '#e0f2fe'}
                    stroke={selectedPartId === 'lens' ? '#0369a1' : '#38bdf8'}
                    strokeWidth={selectedPartId === 'lens' ? '4' : '2.5'}
                    className="cursor-pointer transition-all"
                    onClick={() => setSelectedPartId('lens')}
                  />

                  {/* Diagram Labels */}
                  <text x="86" y="58" fill="#0f172a" fontSize="13" fontWeight="600" className="cursor-pointer" onClick={() => setSelectedPartId('cornea')}>Cornea</text>
                  <text x="148" y="64" fill="#0f172a" fontSize="13" fontWeight="600" className="cursor-pointer" onClick={() => setSelectedPartId('iris')}>Iris</text>
                  <text x="195" y="278" fill="#0f172a" fontSize="13" fontWeight="600" className="cursor-pointer" onClick={() => setSelectedPartId('lens')}>Lens</text>
                  <text x="342" y="40" fill="#0f172a" fontSize="13" fontWeight="600" className="cursor-pointer" onClick={() => setSelectedPartId('retina')}>Retina &amp; Macula</text>
                  <text x="480" y="98" fill="#0f172a" fontSize="13" fontWeight="600" className="cursor-pointer" onClick={() => setSelectedPartId('optic-nerve')}>Optic Nerve</text>
                </svg>
              </div>
            </div>

            {/* Animated Active Part Explanation */}
            <div className="border-t border-slate-200 pt-5 min-h-[124px]">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activePart.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  transition={{ duration: 0.2, ease: EASE_OUT }}
                  className="space-y-3"
                >
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <h4 className="text-xl font-semibold text-slate-900">
                      {activePart.name}
                    </h4>
                    <span className="text-xs font-medium text-slate-500">
                      Related: {activePart.linkedConditions.join(' · ')}
                    </span>
                  </div>
                  <p className="text-sm sm:text-base text-slate-700 leading-relaxed">
                    <strong className="font-semibold text-slate-900">Normal role: </strong>
                    {activePart.role}
                  </p>
                  <p className="text-sm sm:text-base text-slate-700 leading-relaxed">
                    <strong className="font-semibold text-slate-900">When impaired: </strong>
                    {activePart.whenAffected}
                  </p>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>

          {/* Right: The 4 Clinical Degrees of Vision Loss */}
          <div className="lg:col-span-5 flex flex-col justify-between gap-4">
            {SPECTRUM_LEVELS.map((tier, index) => (
              <motion.div
                key={tier.title}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 'some' }}
                transition={{ duration: 0.35, delay: index * 0.06, ease: EASE_OUT }}
                whileHover={{ y: -2 }}
                className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 flex-1 flex flex-col justify-center transition-shadow hover:shadow-sm"
              >
                <div className="flex items-baseline justify-between gap-3 mb-2">
                  <h3 className="text-base sm:text-lg font-semibold text-slate-900">
                    0{index + 1}. {tier.title}
                  </h3>
                  <span className="font-mono-tabular text-xs sm:text-sm font-medium text-sky-700 whitespace-nowrap shrink-0">
                    {tier.acuity}
                  </span>
                </div>
                <p className="text-sm text-slate-600 leading-relaxed">
                  {tier.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
