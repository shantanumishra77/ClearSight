import { useRef } from 'react';
import { ArrowRight } from 'lucide-react';
import { motion, useScroll, useTransform } from 'motion/react';
import { HERO_BANNER_IMAGE } from '../data/visionData';
import { ResilientImage } from './ResilientImage';

const GLOBAL_BENCHMARKS = [
  {
    figure: '2.2 Billion',
    label: 'People worldwide live with near or distant vision impairment.',
    source: 'World Health Organization',
  },
  {
    figure: '1 Billion+',
    label: 'Cases could have been prevented or have not yet been addressed.',
    source: 'WHO Global Vision Report',
  },
  {
    figure: '94 Million',
    label: 'People experience vision loss caused by treatable cataracts.',
    source: 'Leading Cause Worldwide',
  },
  {
    figure: '1 in 12',
    label: 'Men (and 1 in 200 women) have inherited color vision deficiency.',
    source: 'Global Genetics Estimate',
  },
];

const HERO_EASE = [0.16, 1, 0.3, 1] as const;

export function HeroBanner() {
  const bannerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: bannerRef,
    offset: ['start start', 'end start'],
  });

  // Subtle GPU-composited image depth & zoom on scroll
  const imageY = useTransform(scrollYProgress, [0, 1], ['0%', '8%']);
  const imageScale = useTransform(scrollYProgress, [0, 1], [1.02, 1.1]);

  return (
    <section id="banner" aria-labelledby="hero-heading" className="bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-8 sm:pt-8 sm:pb-12">
        {/* Hero Image Banner Frame */}
        <div
          ref={bannerRef}
          className="relative overflow-hidden rounded-2xl bg-slate-900 min-h-[420px] sm:min-h-[480px] lg:min-h-[540px] flex items-end lg:items-center"
        >
          <motion.div
            className="absolute inset-0 w-full h-full"
            style={{ y: imageY, scale: imageScale }}
          >
            <ResilientImage
              src={HERO_BANNER_IMAGE}
              alt="A person seated in warm golden-hour window light looking calmly forward, representing clarity, human dignity, and eye health"
              fallbackTitle="Understanding Blindness & Vision Care"
              className="w-full h-full object-cover object-center"
            />
          </motion.div>

          {/* Measured Contrast Scrim for >= 4.5:1 text legibility */}
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/65 to-slate-950/25 lg:bg-gradient-to-r lg:from-slate-950/92 lg:via-slate-950/70 lg:to-slate-950/20"
          />

          <div className="relative z-10 w-full max-w-2xl px-6 py-10 sm:px-10 sm:py-14 lg:px-14 lg:py-16">
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, ease: HERO_EASE }}
              className="text-sm font-medium text-sky-200 mb-3 tracking-wide"
            >
              Vision Education · Eye Conditions · Daily Care
            </motion.p>

            <motion.h1
              id="hero-heading"
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: 0.06, ease: HERO_EASE }}
              className="font-display text-3xl sm:text-5xl lg:text-[3.25rem] font-semibold text-white leading-[1.12] tracking-tight mb-5"
              style={{ textWrap: 'balance' }}
            >
              Seeing the world through every kind of sight
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: 0.12, ease: HERO_EASE }}
              className="text-base sm:text-lg text-slate-200 leading-relaxed mb-8 max-w-xl"
            >
              Blindness is rarely total darkness. Explore what different forms of vision loss actually look like, understand cataracts and color blindness, and learn practical ways to care for and protect your eyes.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: 0.18, ease: HERO_EASE }}
              className="flex flex-wrap items-center gap-4"
            >
              <motion.a
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
                transition={{ duration: 0.15 }}
                href="#how-people-see"
                className="inline-flex items-center gap-2 px-6 py-3.5 text-sm sm:text-base font-semibold text-slate-950 bg-white rounded-lg hover:bg-sky-50 transition-colors min-h-[44px] whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
              >
                <span>See How People See</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </motion.a>

              <motion.a
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
                transition={{ duration: 0.15 }}
                href="#prevention"
                className="inline-flex items-center px-5 py-3.5 text-sm sm:text-base font-medium text-white border border-white/40 rounded-lg hover:bg-white/10 transition-colors min-h-[44px] whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
              >
                How to Prevent Blindness
              </motion.a>
            </motion.div>
          </div>
        </div>

        {/* Full-width 4-column benchmark strip directly below hero */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-6 border-t border-slate-200">
          {GLOBAL_BENCHMARKS.map((item, idx) => (
            <motion.div
              key={item.figure}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 'some' }}
              transition={{ duration: 0.35, delay: idx * 0.05, ease: HERO_EASE }}
              className="space-y-1.5"
            >
              <p className="font-mono-tabular text-2xl sm:text-3xl font-medium text-slate-900">
                {item.figure}
              </p>
              <p className="text-sm text-slate-700 leading-relaxed">{item.label}</p>
              <p className="text-xs text-slate-500">{item.source}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
