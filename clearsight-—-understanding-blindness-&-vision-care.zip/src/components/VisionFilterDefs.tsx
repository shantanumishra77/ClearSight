import type { CSSProperties } from 'react';
import type { VisionConditionId } from '../data/visionData';
import { ResilientImage } from './ResilientImage';

/**
 * Global hidden SVG <defs> providing scientifically calibrated Brettel/Vienot
 * color-vision deficiency matrices and cataract/luminance optical filters.
 */
export function VisionFilterDefs() {
  return (
    <svg className="sr-only" aria-hidden="true" width="0" height="0">
      <defs>
        {/* Deuteranopia (missing M-cones / green-weak) */}
        <filter id="vision-filter-deuteranopia" colorInterpolationFilters="sRGB">
          <feColorMatrix
            type="matrix"
            values="
              0.625 0.375 0     0 0
              0.700 0.300 0     0 0
              0     0.300 0.700 0 0
              0     0     0     1 0
            "
          />
        </filter>

        {/* Protanopia (missing L-cones / red-weak with darker red luminance) */}
        <filter id="vision-filter-protanopia" colorInterpolationFilters="sRGB">
          <feColorMatrix
            type="matrix"
            values="
              0.567 0.433 0     0 0
              0.558 0.442 0     0 0
              0     0.242 0.758 0 0
              0     0     0     1 0
            "
          />
        </filter>

        {/* Tritanopia (missing S-cones / blue-yellow) */}
        <filter id="vision-filter-tritanopia" colorInterpolationFilters="sRGB">
          <feColorMatrix
            type="matrix"
            values="
              0.950 0.050 0     0 0
              0     0.433 0.567 0 0
              0     0.475 0.525 0 0
              0     0     0     1 0
            "
          />
        </filter>

        {/* Achromatopsia (rod monochromacy luminance) */}
        <filter id="vision-filter-achromatopsia" colorInterpolationFilters="sRGB">
          <feColorMatrix
            type="matrix"
            values="
              0.2126 0.7152 0.0722 0 0
              0.2126 0.7152 0.0722 0 0
              0.2126 0.7152 0.0722 0 0
              0      0      0      1 0
            "
          />
        </filter>
      </defs>
    </svg>
  );
}

interface SimulatedSceneImageProps {
  src: string;
  alt: string;
  condition: VisionConditionId;
  /** Severity from 0.25 (mild) to 1.0 (advanced), default 0.85 */
  severity?: number;
  className?: string;
}

export function SimulatedSceneImage({
  src,
  alt,
  condition,
  severity = 0.85,
  className = '',
}: SimulatedSceneImageProps) {
  const s = Math.max(0.2, Math.min(1, severity));

  const getImageStyle = (): CSSProperties => {
    switch (condition) {
      case 'normal':
        return {};
      case 'cataracts': {
        const blurPx = (1.5 + s * 4.5).toFixed(2);
        const sepiaAmt = (0.12 + s * 0.28).toFixed(2);
        const contrastAmt = (0.85 - s * 0.3).toFixed(2);
        const brightAmt = (1.06 + s * 0.14).toFixed(2);
        return {
          filter: `blur(${blurPx}px) sepia(${sepiaAmt}) contrast(${contrastAmt}) brightness(${brightAmt}) saturate(${(0.85 - s * 0.25).toFixed(2)})`,
          transform: 'scale(1.03)',
        };
      }
      case 'deuteranopia':
        return { filter: 'url(#vision-filter-deuteranopia)' };
      case 'protanopia':
        return { filter: 'url(#vision-filter-protanopia)' };
      case 'tritanopia':
        return { filter: 'url(#vision-filter-tritanopia)' };
      case 'achromatopsia':
        return {
          filter: `url(#vision-filter-achromatopsia) brightness(${(1.08 + s * 0.16).toFixed(2)}) contrast(${(0.9 - s * 0.15).toFixed(2)}) blur(${(s * 1.1).toFixed(2)}px)`,
          transform: 'scale(1.01)',
        };
      case 'glaucoma':
        return {
          filter: `contrast(${(0.98 - s * 0.1).toFixed(2)})`,
        };
      case 'amd':
        return {
          filter: `contrast(${(0.95 - s * 0.08).toFixed(2)})`,
        };
      case 'diabetic-retinopathy':
        return {
          filter: `blur(${(s * 1.2).toFixed(2)}px) contrast(${(0.95 - s * 0.12).toFixed(2)})`,
          transform: 'scale(1.01)',
        };
      case 'retinitis-pigmentosa':
        return {
          filter: `brightness(${(0.82 - s * 0.2).toFixed(2)}) contrast(${(1.05 + s * 0.1).toFixed(2)})`,
        };
      default:
        return {};
    }
  };

  // For partial color vision severity (< 0.9), blend original underneath and filtered on top
  const isColorDeficiency =
    condition === 'deuteranopia' ||
    condition === 'protanopia' ||
    condition === 'tritanopia' ||
    condition === 'achromatopsia';

  return (
    <div className={`relative overflow-hidden bg-slate-900 select-none ${className}`}>
      {/* Base clear image (used when blending partial color severity or as main target) */}
      {isColorDeficiency && s < 0.98 ? (
        <>
          <ResilientImage
            src={src}
            alt={alt}
            className="w-full h-full object-cover"
          />
          <ResilientImage
            src={src}
            alt=""
            className="absolute inset-0 w-full h-full object-cover transition-opacity duration-200"
            style={{ ...getImageStyle(), opacity: s }}
          />
        </>
      ) : (
        <ResilientImage
          src={src}
          alt={alt}
          className="w-full h-full object-cover transition-all duration-200"
          style={getImageStyle()}
        />
      )}

      {/* Cataracts milky glare veil */}
      {condition === 'cataracts' && (
        <div
          aria-hidden="true"
          className="absolute inset-0 pointer-events-none"
          style={{
            background: `radial-gradient(circle at 28% 25%, rgba(255, 250, 230, ${(0.22 + s * 0.34).toFixed(2)}) 0%, rgba(245, 240, 224, ${(0.14 + s * 0.24).toFixed(2)}) 55%, rgba(235, 228, 208, ${(0.18 + s * 0.26).toFixed(2)}) 100%)`,
          }}
        />
      )}

      {/* Glaucoma peripheral tunnel darkening */}
      {condition === 'glaucoma' && (
        <div
          aria-hidden="true"
          className="absolute inset-0 pointer-events-none"
          style={{
            background: `radial-gradient(circle at 50% 50%, rgba(8, 12, 20, 0) ${Math.round(46 - s * 30)}%, rgba(8, 12, 20, 0.72) ${Math.round(68 - s * 28)}%, rgba(4, 7, 14, 0.97) ${Math.round(86 - s * 20)}%)`,
          }}
        />
      )}

      {/* Retinitis Pigmentosa sharp night-dimmed tunnel */}
      {condition === 'retinitis-pigmentosa' && (
        <div
          aria-hidden="true"
          className="absolute inset-0 pointer-events-none"
          style={{
            background: `radial-gradient(circle at 50% 50%, rgba(4, 6, 12, 0) ${Math.round(34 - s * 24)}%, rgba(4, 6, 12, 0.88) ${Math.round(52 - s * 24)}%, rgba(2, 4, 9, 0.99) ${Math.round(68 - s * 22)}%)`,
          }}
        />
      )}

      {/* Age-Related Macular Degeneration central scotoma smudge */}
      {condition === 'amd' && (
        <div
          aria-hidden="true"
          className="absolute inset-0 pointer-events-none flex items-center justify-center"
        >
          <div
            style={{
              width: `${Math.round(28 + s * 28)}%`,
              height: `${Math.round(32 + s * 30)}%`,
              borderRadius: '48% 52% 45% 55%',
              background: `radial-gradient(circle at 48% 48%, rgba(30, 34, 42, ${(0.65 + s * 0.31).toFixed(2)}) 0%, rgba(56, 62, 74, ${(0.55 + s * 0.25).toFixed(2)}) 42%, rgba(82, 88, 100, ${(0.28 + s * 0.16).toFixed(2)}) 68%, rgba(82, 88, 100, 0) 100%)`,
              backdropFilter: `blur(${Math.round(4 + s * 10)}px)`,
              WebkitBackdropFilter: `blur(${Math.round(4 + s * 10)}px)`,
            }}
          />
        </div>
      )}

      {/* Diabetic Retinopathy patchy dark spots & floaters */}
      {condition === 'diabetic-retinopathy' && (
        <svg
          aria-hidden="true"
          viewBox="0 0 400 300"
          preserveAspectRatio="none"
          className="absolute inset-0 w-full h-full pointer-events-none"
          style={{ opacity: Math.min(1, 0.45 + s * 0.55) }}
        >
          <defs>
            <radialGradient id="dr-blotch-1">
              <stop offset="0%" stopColor="#090d14" stopOpacity="0.95" />
              <stop offset="55%" stopColor="#141923" stopOpacity="0.78" />
              <stop offset="100%" stopColor="#141923" stopOpacity="0" />
            </radialGradient>
            <filter id="dr-blur">
              <feGaussianBlur stdDeviation="4" />
            </filter>
          </defs>
          <g filter="url(#dr-blur)">
            <ellipse cx="115" cy="90" rx={26 + s * 22} ry={20 + s * 18} fill="url(#dr-blotch-1)" />
            <ellipse cx="275" cy="145" rx={32 + s * 28} ry={24 + s * 22} fill="url(#dr-blotch-1)" />
            <ellipse cx="195" cy="215" rx={22 + s * 18} ry={16 + s * 16} fill="url(#dr-blotch-1)" />
            <ellipse cx="320" cy="70" rx={18 + s * 14} ry={14 + s * 12} fill="url(#dr-blotch-1)" />
            <ellipse cx="75" cy="210" rx={18 + s * 14} ry={16 + s * 12} fill="url(#dr-blotch-1)" />
          </g>
          {/* Cobweb-like retinal floaters */}
          <path
            d="M150 65 Q175 95 160 125 T185 170"
            fill="none"
            stroke="rgba(15, 23, 42, 0.65)"
            strokeWidth={2 + s * 1.5}
            strokeLinecap="round"
          />
          <path
            d="M240 85 Q225 110 245 140"
            fill="none"
            stroke="rgba(15, 23, 42, 0.5)"
            strokeWidth={1.5 + s}
            strokeLinecap="round"
          />
        </svg>
      )}
    </div>
  );
}
